# GroupProject-Semester4

Creating a predictive model for the pharmacies in belgium associated to the compnay informa